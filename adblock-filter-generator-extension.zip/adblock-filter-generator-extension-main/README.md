# AdBlock Filter Generator

The AdBlock Filter Generator is a Chrome extension that allows users to create a custom adblock filter by combining multiple host files and blocklists. The extension eliminates duplicate lines, discards redundant rules due to existing domain rules, and creates a filter compatible with adblocker syntax.

## Features

- Combine multiple host files and blocklists
- Convert rules to adblock-style syntax
- Remove duplicate lines
- Discard redundant rules due to existing domain rules
- Display the number of duplicate lines removed and domains compressed
- Download the generated filter as a `.txt` file

## Included Filter Lists

The extension comes with a predefined set of filter lists that you can choose from:

- OISD Big
- OISD Small
- HaGeZi's Pro DNS Blocklist
- HaGeZi's Normal DNS Blocklist
- NoTracking
- 1Hosts (Pro)
- 1Hosts (Lite)
- hBlock
- NoTrack Tracker Blocklist

You can select any combination of these filter lists or add your own host files or blocklists to generate a custom filter.

## Installation

To install the AdBlock Filter Generator, follow these steps:

- Download the extension or clone the source code.
- Open Chrome and navigate to `chrome://extensions/`.
- Enable "Developer mode" by toggling the switch in the top-right corner.
- Click "Load unpacked" and select the directory containing the source code.

## Usage

To use the AdBlock Filter Generator, follow these steps:

- Click on the extension icon.
- Select from the available blocklists or upload your own host files.
- Click the "Generate Filter" button.
- The extension will generate the filter and automatically download it as a `.txt` file.

## License

This project is released under the [MIT License](https://opensource.org/licenses/MIT).